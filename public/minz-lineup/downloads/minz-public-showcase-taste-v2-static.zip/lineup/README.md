# MINZ 제품 소개와 샘플

이 자료는 제품을 살펴보기 위한 공개 예제입니다. 실제 고객 자료와 내부 운영 기록을 포함하지 않습니다.

| 제품 | 역할 | 이 패키지에서 확인할 수 있는 것 |
| --- | --- | --- |
| MINZ Skill Factory | Skill의 메타데이터·검증·등록 상태를 관리 | 실행 권한을 부여하지 않는 Schema V2 metadata 예제 |
| MINZ Design Factory | 디자인과 모션을 조합하고 검토 | 별도 Showcase의 네 장면·12개 모션·샘플 다운로드 |
| MINZ AI Control Plane | capability·정책·증거의 계약과 registry 관리 | 미확인 상태를 유지하는 합성 project registry 예제 |
| MINZ Engineering | 소스 구조를 관찰하고 저장한 snapshot을 비교 | snapshot A → 소스 변경 → snapshot B → diff A/B의 설명 예제 |

## 사용법

1. `skill-factory.example.json`으로 metadata 등록과 실행·활성화의 차이를 확인합니다. 예제는 실행·자동호출·Production 권한을 부여하지 않습니다.
2. `control-plane.example.json`으로 UNKNOWN·NOT_INVENTORIED 상태를 확인합니다. 이 파일은 Worker를 생성하거나 queue를 소비하지 않습니다.
3. `engineering-workflow.example.json`은 사용자 흐름 설명입니다. 현재 배포된 CLI 또는 P1A 실행 결과를 증명하지 않습니다. 실제 source가 확인된 패키지의 사용법을 따라야 합니다.
4. Design Showcase에서 네 화면을 전환하고 모션 강도를 선택합니다. Auth에는 가짜 테스트 입력만 사용합니다. Ops는 합성 배송 데이터입니다.

Control Plane의 R13 source/runtime provenance는 이 자료의 검증 범위에 없습니다. 실행 Worker, scheduler, provider 호출은 포함하지 않습니다.

MAVP의 TaskContract → 독립 Git/CI 증거 → ProofReceipt와 Engineering 실행·agentization을 동일한 완료 상태로 해석하지 않습니다.

예제 JSON은 실행 스크립트가 아닙니다. 문의 채널과 공개 배포 URL은 호스팅 대상이 확정된 뒤 안내합니다.
