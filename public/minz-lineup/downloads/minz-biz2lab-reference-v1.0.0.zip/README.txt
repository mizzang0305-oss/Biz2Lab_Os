Non-executable reference pack. Do not install blobs as Skills. No routing or execution authority. Use the independently pinned verification kit.
